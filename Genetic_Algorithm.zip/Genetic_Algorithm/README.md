## Ejemplo de Algoritmo Genetico en python
Este algoritmo encuentra la frase objetivo "Genetics Algorithms", a travez de caracteres aleatorios.
## Requisitos
- Python 2.7
- Librería numpy
## Instalacion
Si utilizas entorno linux, puedes ejecutar los siguientes comandos para instalar los requisitos. 
``` 
sudo apt-get install python
sudo apt-get install python-pip
pip install numpy

``` 
## Ejecutar
Para ejecutar el algoritmo por tu cuenta.
```
python main.py
```  
